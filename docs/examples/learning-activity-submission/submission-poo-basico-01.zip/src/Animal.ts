export class Animal {
	// AI-REVIEW [encapsulamiento] [alta] [encapsulamiento]:
	// Observación: El estado de la clase sigue siendo modificable directamente desde fuera, por lo que no se protegen los invariantes de nombre no vacío y energía no negativa.
	// Pregunta pedagógica: ¿Qué modificador de visibilidad impediría que otro módulo cambie name o energy sin pasar por una operación controlada?
	// Sugerencia conceptual: Mantén el estado interno protegido y ofrece métodos o accesores que validen las reglas antes de aceptar cambios.
	// Evidencia esperada del estudiante: La construcción y cualquier modificación posterior rechazan nombres vacíos y valores de energía negativos sin exponer escritura directa del estado.
	public constructor(
		private name: string,
		private energy: number
	) {
		if (energy < 0)
			throw Error("La energia no puede ser menor que 0")
		if (name == "")
			throw Error("El nombre no puede ser vacio")
	}

	public getEnergy(): number {
		return this.energy
	}

	public getName(): string {
		return this.name
	}

	public feed(amount:number){
		if (amount <= 0)
			throw Error("Tengo hambre!")
		this.energy += amount
	}

	public describe():string {
		return "Hola, soy " + this.name + " y tengo " + this.energy.toString() + " de energia"
	}
}
